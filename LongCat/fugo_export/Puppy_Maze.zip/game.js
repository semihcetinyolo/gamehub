// Long Dog — screens, input, animation. Logic: engine.js · board: render.js · dog: dog.js (+ art.js)
(() => {
const E = window.LongCatEngine, R = window.LongCatRender, D = window.LongDog, LEVELS = window.LEVELS;
const $ = id => document.getElementById(id);

// ---------- saves (per-browser convenience) ----------
const SAVE = 'longdog.v1';
let prog = { stars: {} };
try { prog = JSON.parse(localStorage.getItem(SAVE)) || prog; } catch (e) {}
const saveProg = () => { try { localStorage.setItem(SAVE, JSON.stringify(prog)); } catch (e) {} };
const pref = (k, d) => { try { return localStorage.getItem('longdog.' + k) ?? d; } catch (e) { return d; } };
const setPref = (k, v) => { try { localStorage.setItem('longdog.' + k, v); } catch (e) {} };
let soundOn = pref('sound', 'on') !== 'off', depth = pref('depth', 'soft'), failMode = pref('fail', 'restart');

// ---------- audio + haptics ----------
let ac = null;
function audio() { if (!ac) { try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) {} } if (ac && ac.state === 'suspended') ac.resume(); return ac; }
function tone(f0, f1, dur, type = 'sine', vol = .2, delay = 0) {
  if (!soundOn) return; const a = audio(); if (!a) return;
  const t = a.currentTime + delay, o = a.createOscillator(), g = a.createGain();
  o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(.001, t + dur);
  o.connect(g).connect(a.destination); o.start(t); o.stop(t + dur + .02);
}
const SFX = {
  slide: n => tone(300, 300 + n * 45, .06 + n * .018, 'triangle', .07),
  bonk: n => tone(260 + Math.min(n, 8) * 22, 150, .1, 'sine', .28),
  undo: () => tone(520, 300, .09, 'triangle', .12),
  win: () => [659, 784, 988, 1318].forEach((f, i) => tone(f, f, .16, 'triangle', .18, i * .08)),
  stuck: () => { tone(640, 420, .16, 'sine', .18); tone(470, 300, .3, 'sine', .16, .16); },
  rewind: () => tone(900, 250, .35, 'triangle', .1),
  hint: () => tone(880, 1320, .12, 'triangle', .12),
  glass: () => { tone(2400, 1800, .08, 'square', .05); tone(3100, 2200, .12, 'triangle', .06, .03); },
  box: () => tone(180, 120, .12, 'sawtooth', .07),
};
const buzz = ms => { try { if (navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) navigator.vibrate(ms); } catch (e) {} };

// ---------- menus ----------
if (window.DOG_ART && DOG_ART.logo) $('logo').innerHTML = `<img src="${DOG_ART.logo}" alt="Puppy Maze">`;
function show(id) {
  if (id !== 'game' && location.hash) history.replaceState(null, '', location.pathname + location.search);
  document.querySelectorAll('.screen').forEach(s => s.classList.toggle('on', s.id === id));
  if (id === 'map') home.start(); else home.stop();
  if (id === 'game') kick();
  syncClock();
}
const thumbs = {};
function thumb(i) {
  if (thumbs[i]) return thumbs[i];
  const L = E.parse(LEVELS[i]), s = 8, cv = document.createElement('canvas');
  cv.width = L.W * s + 4; cv.height = L.H * s + 4; const g = cv.getContext('2d');
  g.fillStyle = R.wallTheme(i).top; g.beginPath(); g.roundRect(0, 0, cv.width, cv.height, 5); g.fill();
  for (let y = 0; y < L.H; y++) for (let x = 0; x < L.W; x++) if (L.open[y * L.W + x]) {
    const t = L.t[y * L.W + x];
    g.fillStyle = y * L.W + x === L.start ? '#c9692e' : t === E.T.GLASS ? '#9fd3ea' : t === E.T.BOX ? '#a8743f' : t === E.T.FLOOR ? '#fff1d9' : '#f2b25c';
    g.fillRect(2 + x * s, 2 + y * s, s - 1, s - 1);
  }
  return thumbs[i] = cv.toDataURL();
}
function renderMenus() {
  const total = LEVELS.reduce((n, _, i) => n + (prog.stars[i] || 0), 0);
  const done = LEVELS.filter((_, i) => prog.stars[i] > 0).length;
  const firstOpen = LEVELS.findIndex((_, i) => !prog.stars[i]), next = firstOpen < 0 ? 0 : firstOpen;
  $('totalStars').textContent = total;
  $('mapProgress').textContent = `${done} / ${LEVELS.length} bölüm`;
  $('bContinue').innerHTML = '<strong>OYNA</strong>';
  $('bContinue').onclick = () => { audio(); start(next); };
  const box = $('levels'); box.innerHTML = '';
  LEVELS.forEach((lv, i) => {
    const st = prog.stars[i] || 0, b = document.createElement('button');
    b.className = 'lvl' + (i === firstOpen ? ' next' : '') + (lv.hard ? ' hard' : '');
    b.setAttribute('aria-label', `Bölüm ${i + 1}: ${lv.name}, ${st} yıldız${lv.hard ? ', zor' : ''}`);
    b.innerHTML = `<div class="level-art"><img src="${thumb(i)}" alt=""><div class="n">${String(i + 1).padStart(2, '0')}</div></div><div class="nm">${lv.name}</div><div class="st" aria-hidden="true">${'<b>★</b>'.repeat(st)}${'★'.repeat(3 - st)}</div>`;
    b.onclick = () => { audio(); start(i); }; box.appendChild(b);
  });
}
$('bLevels').onclick = () => { renderMenus(); show('levelSelect'); };
$('bLevelsBack').onclick = () => show('map');
$('bMap').onclick = () => { renderMenus(); show('map'); };
// ---------- solve timer: counts only while the level is on screen and being played ----------
// (paused in settings, in a background tab and after the win; fails and restarts keep counting)
const clock = { ms: 0, since: 0, done: false, shown: -1 };
const clockNow = () => clock.ms + (clock.since ? performance.now() - clock.since : 0);
function syncClock() {
  const run = !clock.done && L && $('game').classList.contains('on') && $('settings').hidden && !document.hidden;
  if (run && !clock.since) clock.since = performance.now();
  else if (!run && clock.since) { clock.ms += performance.now() - clock.since; clock.since = 0; }
}
const fmtTime = ms => { const s = Math.floor(ms / 1000); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
function showClock() { const s = Math.floor(clockNow() / 1000); if (s !== clock.shown) { clock.shown = s; $('lvlTime').textContent = ' · ' + fmtTime(s * 1000); } }
document.addEventListener('visibilitychange', syncClock);
const TIMES = 'longdog.times'; // { levelNo: [{ s, f, h, u }] } — solve times for balancing
const readTimes = () => { try { return JSON.parse(localStorage.getItem(TIMES)) || {}; } catch (e) { return {}; } };
function recordTime(ms) {
  const all = readTimes(), k = idx + 1;
  (all[k] = all[k] || []).push({ s: Math.round(ms / 100) / 10, f: attempt.fails, h: attempt.hints, u: attempt.undos });
  try { localStorage.setItem(TIMES, JSON.stringify(all)); } catch (e) {}
}
function timesReport() {
  const all = readTimes();
  return JSON.stringify(LEVELS.map((lv, i) => ({ level: i + 1, est: lv.secs, runs: all[i + 1] || [] })).filter(r => r.runs.length));
}
const openSettings = () => { $('settings').hidden = false; syncClock(); }, closeSettings = () => { $('settings').hidden = true; syncClock(); };
$('bTimes').onclick = () => {
  const text = timesReport(), ta = document.createElement('textarea');
  ta.value = text; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select();
  let ok = false; try { ok = document.execCommand('copy'); } catch (e) {} ta.remove();
  if (!ok) prompt('Süreleri kopyala:', text);
  $('timesState').textContent = ok ? 'KOPYALANDI' : '';
};
$('bSettings').onclick = $('bSettingsGame').onclick = openSettings; $('bSettingsClose').onclick = closeSettings;
$('settings').addEventListener('click', e => { if (e.target === $('settings')) closeSettings(); });
function settingsUI() {
  $('soundState').textContent = soundOn ? 'AÇIK' : 'KAPALI'; $('bSound').setAttribute('aria-pressed', String(soundOn));
  $('depthState').textContent = depth === 'flat' ? 'DÜZ' : 'DERİNLİKLİ'; $('bDepth').setAttribute('aria-pressed', String(depth !== 'flat'));
  $('failState').textContent = failMode === 'checkpoint' ? 'CHECKPOINT' : 'RESTART';
}
$('bFail').onclick = () => { failMode = failMode === 'restart' ? 'checkpoint' : 'restart'; setPref('fail', failMode); settingsUI(); };
$('bSound').onclick = () => { soundOn = !soundOn; setPref('sound', soundOn ? 'on' : 'off'); settingsUI(); };
$('bDepth').onclick = () => { depth = depth === 'flat' ? 'soft' : 'flat'; setPref('depth', depth); settingsUI(); home.rebake(); if (L) resize(); };
$('bReset').onclick = () => { if (!confirm('Tüm yıldızlar silinsin mi?')) return; prog = { stars: {} }; saveProg(); renderMenus(); };
settingsUI();

// ---------- game state ----------
const cv = $('cv'), ctx = cv.getContext('2d');
const headCv = document.createElement('canvas'), hctx = headCv.getContext('2d');
let idx = 0, lv = null, L = null, S = null, st = null, lay = null, board = null, dpr = 1;
let rewindDirs = [], anim = null, rewind = null, queued = [], over = false, attempt = null;
let mood = 'idle', fx = D.newFace(), lastDir = [0, 1], squashAt = -1e9, bonkLen = 0, lastT = 0;
let boxAnim = null, particles = [], trail = [], hint = null, tipTimer = 0, failTimer = 0, idleAt = 0, idleNudged = false;
// Opening hint (Longcat's win-streak reward): Longcat puzzles trap the very first swipe, so while the dog
// is on the solution's opening the paw hint plays its next swipe by itself — the 1st swipe on a 5+ level
// win streak (no stuck) or after the 2nd stuck in the same level, the first 2 swipes after the 5th stuck.
// Free: it costs no star.
const STREAK_HINT = 5, FAILS_HINT = 2, FAILS_HINT2 = 5, LETTER = { u: 'up', r: 'right', d: 'down', l: 'left' };
function openingHint() {
  if (!L || over || anim || rewind) return;
  const shown = attempt.fails >= FAILS_HINT2 ? 2 : (prog.streak || 0) >= STREAK_HINT || attempt.fails >= FAILS_HINT ? 1 : 0, n = st.moves.length;
  if (n >= shown) return;
  const sol = lv.solution && [...lv.solution].map(c => LETTER[c]);
  if (sol && st.moves.some((m, k) => m.dir !== sol[k])) return; // left the solution's line
  const d = sol ? sol[n] : S.hint(st);
  if (d) showHint(true, d);
}
const IDLE_NUDGE = 12000; // no move for this long → the hint button wiggles once (Longcat warns at 6.3 / 12 s)
const stirred = () => { idleAt = performance.now(); idleNudged = false; };

function start(i) {
  if (!LEVELS[i]) return;
  idx = i; lv = LEVELS[i]; L = E.parse(lv); S = E.makeSolver(L);
  attempt = { hints: 0, undos: 0, fails: 0, restarts: 0 };
  clock.ms = 0; clock.since = 0; clock.done = false; clock.shown = -1; showClock();
  $('lvlNo').innerHTML = `BÖLÜM ${i + 1}${lv.hard ? '<span class="tag">ZOR</span>' : ''}`;
  $('lvlName').textContent = lv.name;
  history.replaceState(null, '', '#' + (i + 1));
  reset();
  show('game'); resize(); syncClock();
  tip(lv.tip || '', lv.tip ? (lv.intro ? 6500 : 4200) : 0);
  if (!lv.tip && prog.streak === STREAK_HINT) tip(`${STREAK_HINT} bölüm üst üste! Seri sürdükçe ilk hamle gösterilir.`, 3600);
  if (i === 0) setTimeout(() => { if (idx === 0 && !st.moves.length) showHint(true); }, 700);
}
function reset() { // fresh board for the current level
  clearTimeout(failTimer);
  st = E.newState(L); anim = null; rewind = null; queued = []; over = false; particles = []; trail = []; hint = null; boxAnim = null;
  mood = 'idle'; fx = D.newFace(); lastDir = tailDir().map(v => -v); stirred();
  $('result').classList.remove('on'); hud(); openingHint(); kick();
}
function restart() { if (!L || rewind) return; attempt.restarts++; reset(); }
function tailDir() { // the tail points at a solid side of the start cell
  const x = L.start % L.W, y = (L.start / L.W) | 0;
  for (const d of ['down', 'left', 'right', 'up']) {
    const [dx, dy] = E.DIRS[d], nx = x + dx, ny = y + dy;
    if (nx < 0 || ny < 0 || nx >= L.W || ny >= L.H || !L.open[ny * L.W + nx]) return [dx, dy];
  }
  return [0, 1];
}
function hud() {
  $('progressFill').style.width = (st.count / st.need * 100).toFixed(1) + '%';
}
function tip(text, ms) {
  clearTimeout(tipTimer); const t = $('tip');
  if (!text) { t.classList.remove('on'); return; }
  t.textContent = text; t.classList.add('on');
  if (ms) tipTimer = setTimeout(() => t.classList.remove('on'), ms);
}

// ---------- layout ----------
function resize() {
  if (!L) return;
  const r = $('stage').getBoundingClientRect(); if (!r.width) return;
  dpr = Math.min(2.5, window.devicePixelRatio || 1);
  cv.width = Math.round(r.width * dpr); cv.height = Math.round(r.height * dpr);
  lay = R.layout(L, r.width, r.height);
  board = R.bakeBoard(L, lay, dpr, depth, idx);
  const hs = Math.ceil(lay.cell * 2.6 * dpr); headCv.width = headCv.height = hs;
  kick();
}
addEventListener('resize', () => { resize(); home.resize(); });
const center = i => ({ x: lay.ox + (i % L.W + 0.5) * lay.cell, y: lay.oy + (((i / L.W) | 0) + 0.5) * lay.cell });

// ---------- input ----------
const SLIDE_SPEED = 0.6; // 1 = the first prototype's pace (~33 cells/s); 0.8 = 80% of it
function nudge(dir) { // blocked: a small nudge of the head, never the screen
  lastDir = E.DIRS[dir].slice(); squashAt = performance.now() - 60; bonkLen = 0; D.trigger(fx, 'squish', .12); kick();
}
// returns true when a slide started
function input(dir) {
  if (!L || over || !$('game').classList.contains('on')) return false;
  audio(); stirred();
  if (anim) { // chained swipes run in order once the current slide lands
    const lastQ = queued.length ? queued[queued.length - 1] : anim.undo ? null : anim.dir;
    if (dir !== lastQ && queued.length < 3) queued.push(dir);
    return false;
  }
  const m = E.apply(L, st, dir);
  if (!m) { nudge(dir); return false; }
  const n = m.cells.length;
  hint = null; lastDir = E.DIRS[dir].slice(); mood = n ? 'slide' : 'idle';
  if (n >= 5) D.trigger(fx, 'surprise', .2);
  // a swipe that only breaks glass or pushes a box in front of the dog is a short bump
  anim = { dir, m, t0: performance.now(), dur: n ? (50 + n * 30) / SLIDE_SPEED : 150, undo: false };
  if (n) SFX.slide(n); else bump(m, performance.now());
  if (lv.tip && st.moves.length >= 2) tip('');
  hud(); kick(); return true;
}
function undo() {
  if (!L || anim || over || !st.moves.length) return;
  audio();
  const m = E.undo(L, st);
  attempt.undos++; hint = null; mood = 'idle'; boxAnim = null;
  anim = { dir: m.dir, m, t0: performance.now(), dur: 40 + m.cells.length * 16, undo: true };
  SFX.undo(); hud(); kick();
}
const HINT_STEP = 320, HINT_HOLD = 900, HINT_EASE = 300, HINT_PASSES = 3; // ms between paws, full-trail hold, per-paw ease-in; loops
function showHint(auto, dir) {
  if (!L || over || anim) return;
  const d = dir || S.hint(st);
  if (!auto) { attempt.hints++; SFX.hint(); }
  if (d) {
    const m = E.move(L, st, d), now = performance.now();
    const cells = m.cells.length ? m.cells : m.mut.slice(0, 1).map(x => x[0]); // in-place: light the glass / box
    hint = { dir: d, cells, t0: now, until: now + HINT_PASSES * (cells.length * HINT_STEP + HINT_HOLD) }; // a few full passes; any move clears it
  }
  else { tip('Bu yoldan çıkış yok — baştan dene.', 2600); $('bRestart').classList.remove('nudge'); void $('bRestart').offsetWidth; $('bRestart').classList.add('nudge'); }
  kick();
}
$('bHint').onclick = () => showHint(false);
$('bUndo').onclick = () => { // the icon spins back even when there is nothing to undo
  const b = $('bUndo'); b.classList.remove('spin'); void b.offsetWidth; b.classList.add('spin'); undo();
};
$('bRestart').onclick = () => { audio(); restart(); };
$('rRetry').onclick = restart;
$('rNext').onclick = () => { if (idx + 1 < LEVELS.length) start(idx + 1); else { renderMenus(); show('levelSelect'); } };

const KEYS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right' };
addEventListener('keydown', e => {
  if (e.key === 'Escape' && !$('settings').hidden) { closeSettings(); return; }
  if (!$('game').classList.contains('on')) return;
  const k = e.key.length === 1 ? e.key.toLowerCase() : e.key;
  if (KEYS[k]) { e.preventDefault(); input(KEYS[k]); }
  else if (k === 'z' || k === 'Backspace') undo();
  else if (k === 'r') restart();
  else if (k === 'h') showHint(false);
});
// Drag: one finger can steer several slides without lifting — every 18 px of travel re-anchors
// the gesture, and a new direction fires a new swipe (queued while the dog is still moving).
// Tap: a floor cell in the dog's row or column that its slide would pass sends it that way.
const SWIPE_PX = 18;
let touch = null;
cv.addEventListener('pointerdown', e => { touch = { x: e.clientX, y: e.clientY, fired: null, moved: false }; try { cv.setPointerCapture(e.pointerId); } catch (_) {} });
cv.addEventListener('pointermove', e => {
  if (!touch) return;
  const dx = e.clientX - touch.x, dy = e.clientY - touch.y;
  if (Math.hypot(dx, dy) < SWIPE_PX) return;
  const dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 'right' : 'left') : (dy > 0 ? 'down' : 'up');
  touch.x = e.clientX; touch.y = e.clientY; touch.moved = true;
  if (dir !== touch.fired) { touch.fired = dir; input(dir); }
});
cv.addEventListener('pointerup', e => { if (touch && !touch.moved) tapAt(e.clientX, e.clientY); touch = null; });
cv.addEventListener('pointercancel', () => { touch = null; });
function tapAt(px, py) {
  if (!L || !lay || over) return;
  const r = cv.getBoundingClientRect();
  const x = Math.floor((px - r.left - lay.ox) / lay.cell), y = Math.floor((py - r.top - lay.oy) / lay.cell);
  if (x < 0 || y < 0 || x >= L.W || y >= L.H) return;
  const target = y * L.W + x;
  if (!L.open[target]) return;
  // where the head will be once the current slide and any queued swipes have landed
  const sim = E.cloneState(st);
  for (const d of queued) E.apply(L, sim, d);
  if (sim.filled[target]) return;
  const head = sim.head, hx = head % L.W, hy = (head / L.W) | 0;
  const dir = y === hy ? (x > hx ? 'right' : 'left') : x === hx ? (y > hy ? 'down' : 'up') : null;
  if (!dir) return;
  const m = E.move(L, sim, dir);
  if (m && (m.cells.includes(target) || m.mut.some(x => x[0] === target))) input(dir);
  else if (!anim && !queued.length) nudge(dir); // out of reach: the head bumps toward it, nothing moves
}

// ---------- frame loop (runs while the game screen is up; the face is always alive) ----------
let raf = 0;
function kick() { if (!raf) raf = requestAnimationFrame(frame); }
function frame(now) { raf = 0; if (!$('game').classList.contains('on')) return; showClock(); draw(now); kick(); }

// what happens in front of the resting dog: glass shatters, a box slides one cell
function bump(m, now) {
  for (const [i, o, n] of m.mut) {
    const p = center(i);
    if (o === E.T.GLASS) {
      SFX.glass(); buzz(14);
      for (let k = 0; k < 10; k++) particles.push({ x: p.x, y: p.y, vx: (Math.random() - .5) * lay.cell * 4, vy: (Math.random() - .7) * lay.cell * 4, t0: now, life: 420, r: lay.cell * (.06 + Math.random() * .07), kind: 'shard', rot: Math.random() * 6 });
    }
    if (n === E.T.BOX) { boxAnim = { to: i, from: m.mut.find(x => x[1] === E.T.BOX)[0], t0: now }; SFX.box(); buzz(10); }
  }
}
function finishAnim(now) {
  const a = anim; anim = null;
  if (!a.undo) {
    squashAt = now; bonkLen = a.m.cells.length; D.trigger(fx, 'squish', .16); mood = 'idle';
    if (a.m.cells.length) { SFX.bonk(a.m.cells.length); buzz(8); bump(a.m, now); }
    lastDir = E.DIRS[a.m.last].slice();
    const h = center(st.head), [dx, dy] = E.DIRS[a.m.last];
    for (let k = 0; k < 6; k++) {
      const sp = (Math.random() - .5) * 1.6;
      particles.push({ x: h.x + dx * lay.cell * .48, y: h.y + dy * lay.cell * .48, vx: (-dx * .5 + dy * sp) * lay.cell * 2.2, vy: (-dy * .5 + dx * sp) * lay.cell * 2.2, t0: now, life: 260, r: lay.cell * (.07 + Math.random() * .06), kind: 'dust' });
    }
    if (E.won(L, st)) win(now);
    else if (E.stuck(L, st)) fail(now);
  } else mood = 'idle';
  if (!over) openingHint();
  hud();
  while (queued.length && !over && !input(queued.shift())); // skip queued swipes that are blocked
  if (over) queued = [];
}
function win(now) {
  over = true; mood = 'happy'; SFX.win(); hud();
  const solveMs = clockNow(); clock.done = true; syncClock(); recordTime(solveMs); showClock(); $('rTime').textContent = 'Süre ' + fmtTime(solveMs);
  bodyPieces(null).flat().forEach((p, i) => { for (let k = 0; k < 2; k++) particles.push({ x: p.x, y: p.y, vx: (Math.random() - .5) * lay.cell * 3, vy: -lay.cell * (1.5 + Math.random() * 2), t0: now + i * 45, life: 700, r: lay.cell * .16, kind: 'star', rot: Math.random() * 6 }); });
  const stars = !attempt.hints && !attempt.undos && !attempt.fails ? 3 : !attempt.hints ? 2 : 1;
  prog.stars[idx] = Math.max(prog.stars[idx] || 0, stars); prog.streak = attempt.fails ? 1 : (prog.streak || 0) + 1; saveProg();
  setTimeout(() => card(stars), 750);
}
// Stuck = fail, and a fail always restarts: sad face, the dog rewinds to its start, fresh board.
function fail(now) {
  over = true; mood = 'dead'; attempt.fails++; prog.streak = 0; saveProg(); SFX.stuck(); buzz([20, 40, 20]); hud();
  failTimer = setTimeout(() => {
    rewindDirs = st.moves.map(m => m.dir);
    const pts = bodyPieces(null);
    let keepMoves = 0;
    if (failMode === 'checkpoint') { // furthest prefix of this run that can still be solved
      const t = E.newState(L);
      for (let i = 0; i < st.moves.length; i++) { E.apply(L, t, st.moves[i].dir); if (S.solvable(t)) keepMoves = i + 1; }
    }
    const keep = keepMoves ? piecesLen(piecesOf(st.moves.slice(0, keepMoves))) : 0;
    rewind = { t0: performance.now(), dur: 280 + (st.moves.length - keepMoves) * 25, pts, keep, keepMoves }; SFX.rewind(); kick();
  }, 950);
}
function card(stars) {
  $('rTitle').textContent = ['', 'Bitti!', 'Harika!', 'Kusursuz!'][stars];
  $('rStars').innerHTML = '<b>★</b>'.repeat(stars) + '★'.repeat(3 - stars);
  $('rNote').textContent = stars === 3 ? 'İpucusuz, geri almadan.' : stars === 2 ? '★★★ için geri almadan bitir.' : '★★ için ipucusuz bitir.';
  $('rNext').textContent = idx + 1 < LEVELS.length ? 'Sonraki ›' : 'Bölümler ›';
  const f = $('rFace'), g = f.getContext('2d'); g.clearRect(0, 0, f.width, f.height);
  D.drawHead(g, f.width / 2, f.height * .55, f.height * .72, { fx: D.newFace(), state: 'happy', t: .1 });
  $('result').classList.add('on');
}

// The body as polylines tail → head through cell centres. A pit or portal breaks it into pieces:
// each piece after the first comes out of a hole. `a` = current animation (partial last move).
function piecesOf(moves, a = null, p = 1) {
  const pieces = [[center(L.start)]];
  const add = (m, frac) => {
    let k = frac * m.cells.length;
    m.segs.forEach((seg, si) => {
      if (k <= 0) return;
      if (si) pieces.push([]);
      const piece = pieces[pieces.length - 1];
      for (const q of seg) {
        if (k <= 0) break;
        const c = center(q);
        if (k >= 1 || !piece.length) { if (k >= 1) piece.push(c); k -= 1; continue; }
        const b = piece[piece.length - 1]; piece.push({ x: b.x + (c.x - b.x) * k, y: b.y + (c.y - b.y) * k }); k = 0;
      }
    });
  };
  for (const m of moves) add(m, 1);
  if (a) add(a.m, a.undo ? 1 - p : p);
  return pieces.filter((pc, i) => pc.length || i === 0);
}
const bodyPieces = (a, p = 1) => piecesOf(a && !a.undo ? st.moves.slice(0, -1) : st.moves, a, p);
const piecesLen = ps => ps.reduce((s, pc) => s + polyLen(pc), 0);
function truncPieces(ps, keep) { // the first `keep` px of the body, across pieces
  const out = [];
  for (const pc of ps) { const l = polyLen(pc); if (keep >= l) { out.push(pc); keep -= l; continue; } out.push(truncate(pc, keep)); break; }
  return out.length ? out : [ps[0].slice(0, 1)];
}
function truncate(pts, keep) { // first `keep` px of a polyline
  const out = [pts[0]];
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], b = pts[i], len = Math.hypot(b.x - a.x, b.y - a.y);
    if (keep >= len) { out.push(b); keep -= len; continue; }
    out.push({ x: a.x + (b.x - a.x) * keep / len, y: a.y + (b.y - a.y) * keep / len }); break;
  }
  return out;
}
const polyLen = pts => pts.reduce((s, p, i) => i ? s + Math.hypot(p.x - pts[i - 1].x, p.y - pts[i - 1].y) : 0, 0);

function draw(now) {
  if (!lay) return;
  if (!over && !anim && !rewind && !hint && !idleNudged && $('settings').hidden && now - idleAt > IDLE_NUDGE) {
    idleNudged = true; const b = $('bHint'); b.classList.remove('nudge'); void b.offsetWidth; b.classList.add('nudge');
  }
  const dt = Math.min(.05, (now - (lastT || now)) / 1000); lastT = now;
  const c = lay.cell;
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height);
  ctx.drawImage(board, 0, 0);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  drawMechs(now);
  // paws on empty floor (all of them while rewinding — the body covers the rest)
  const pending = anim ? new Set(anim.m.cells) : null;
  for (let i = 0; i < L.open.length; i++) {
    if (shownType(i) !== E.T.FLOOR && !(rewind && L.t[i] === E.T.FLOOR)) continue;
    if (!rewind && st.filled[i] && !(pending && pending.has(i))) continue;
    if (boxAnim && i === boxAnim.to) continue;
    const p = center(i); R.paw(ctx, p.x, p.y, c * .42, R.PAL.paw);
  }
  if (hint && now > hint.until) hint = null;
  if (hint) { // the paws on the hinted path light up one after another, walking away from the dog
    const cycle = hint.cells.length * HINT_STEP + HINT_HOLD, el = (now - hint.t0) % cycle;
    const fadeOut = Math.min(1, (hint.until - now) / 400);
    const cycleFade = el > cycle - 400 ? (cycle - el) / 400 : 1; // the whole trail dims before the next pass
    hint.cells.forEach((i, k) => {
      const on = Math.min(1, Math.max(0, (el - k * HINT_STEP) / HINT_EASE)); // each paw eases in on its turn
      if (!on) return;
      const a = on * fadeOut * cycleFade, pop = on < 1 ? on * (1 - on) * .5 : 0, p = center(i);
      const glow = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, c * .55);
      glow.addColorStop(0, `rgba(255,214,110,${.32 * a})`); glow.addColorStop(1, 'rgba(255,214,110,0)');
      ctx.fillStyle = glow; ctx.fillRect(p.x - c * .55, p.y - c * .55, c * 1.1, c * 1.1);
      const sz = c * (.44 + pop * .2);
      ctx.globalAlpha = a * .75;
      R.paw(ctx, p.x, p.y + c * .015, sz * 1.1, '#c8914a'); // soft rim so the gold still reads on cream
      R.paw(ctx, p.x, p.y, sz, '#f6cf72');
      ctx.globalAlpha = 1;
    });
  }
  let p = 1, pts;
  if (anim) { const u = Math.min(1, (now - anim.t0) / anim.dur); p = anim.undo ? u : 1 - (1 - u) * (1 - u); }
  if (rewind) {
    const u = Math.min(1, (now - rewind.t0) / rewind.dur), k = u * u * (3 - 2 * u);
    const full = piecesLen(rewind.pts);
    pts = truncPieces(rewind.pts, rewind.keep + (full - rewind.keep) * (1 - k));
    if (u >= 1) {
      if (rewind.keepMoves) {
        const n = rewind.keepMoves; reset(); hint = null; // back mid-run, not on the start
        for (let i = 0; i < n; i++) E.apply(L, st, rewindDirs[i]);
        openingHint();
        lastDir = E.DIRS[rewindDirs[n - 1]]; hud(); tip('Sıkıştın — son çözülebilir hamleye döndün.', 1800);
      } else { reset(); { const t = { [FAILS_HINT]: 'Sıkıştın — ilk hamle gösteriliyor.', [FAILS_HINT2]: 'Sıkıştın — ilk iki hamle gösteriliyor.' }[attempt.fails]; tip(t || 'Sıkıştın — baştan!', t ? 2200 : 1400); } }
      pts = bodyPieces(null);
    }
  } else pts = bodyPieces(anim, p);
  const lastPiece = pts[pts.length - 1], head = lastPiece[lastPiece.length - 1];
  if (anim && !anim.undo && lastPiece.length > 1) { // the head looks the way it is moving (turns, arrows)
    const b = lastPiece[lastPiece.length - 2], l = Math.hypot(head.x - b.x, head.y - b.y);
    if (l > 1) lastDir = [Math.round((head.x - b.x) / l), Math.round((head.y - b.y) / l)];
  }

  // face
  const sliding = anim && !anim.undo;
  // worried when cornered: one way out, and it is short
  const ways = !anim && !over && st.moves.length ? E.legal(L, st) : null;
  const cornered = ways && ways.length === 1 && E.move(L, st, ways[0]).cells.length <= 2;
  D.stepFace(fx, dt, { state: mood, look: lastDir, hint: hint && E.DIRS[hint.dir], worried: cornered });
  const sqT = (now - squashAt) / 170, squash = sqT >= 0 && sqT < 1 ? Math.sin(sqT * Math.PI) * (1 - sqT) * (bonkLen ? Math.min(1, .45 + bonkLen * .08) : .35) : 0;

  // motion blur: faded copies of the head along the path it just travelled
  for (const g of trail) g.life -= dt;
  trail = trail.filter(g => g.life > 0);
  if (sliding || rewind) trail.push({ x: head.x, y: head.y, life: .1 });

  pts.forEach((pc, k) => D.drawBody(ctx, pc, c, { tailDir: tailDir(), depth, state: mood, t: now / 1000, cont: k > 0 }));
  // head → bitmap once, then blit ghosts + head
  const hs = headCv.width; hctx.setTransform(1, 0, 0, 1, 0, 0); hctx.clearRect(0, 0, hs, hs); hctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  D.drawHead(hctx, hs / dpr / 2, hs / dpr / 2, c, { fx, state: mood, dir: lastDir, squash, stretch: sliding ? .07 : 0, t: now / 1000 });
  const blit = (x, y) => ctx.drawImage(headCv, x - hs / dpr / 2, y - hs / dpr / 2, hs / dpr, hs / dpr);
  trail.forEach((g, i) => { ctx.globalAlpha = .28 * (g.life / .1) * ((i + 1) / trail.length); blit(g.x, g.y); });
  ctx.globalAlpha = 1; blit(head.x, head.y);

  // particles
  particles = particles.filter(q => now - q.t0 < q.life);
  for (const q of particles) {
    const t = (now - q.t0) / 1000; if (t < 0) continue;
    const k = (now - q.t0) / q.life, x = q.x + q.vx * t, y = q.y + q.vy * t + (q.kind === 'star' ? 600 * t * t : 0);
    ctx.globalAlpha = 1 - k;
    if (q.kind === 'dust') { ctx.fillStyle = '#fff8ea'; ctx.beginPath(); ctx.arc(x, y, q.r * (1 + k), 0, Math.PI * 2); ctx.fill(); }
    else if (q.kind === 'shard') { ctx.fillStyle = '#bfe6f5'; ctx.save(); ctx.translate(x, y + 500 * t * t); ctx.rotate(q.rot + t * 8); ctx.beginPath(); ctx.moveTo(0, -q.r); ctx.lineTo(q.r * .8, q.r * .6); ctx.lineTo(-q.r * .7, q.r * .4); ctx.closePath(); ctx.fill(); ctx.restore(); }
    else { ctx.fillStyle = '#ffd45e'; ctx.save(); ctx.translate(x, y); ctx.rotate(q.rot + t * 5); star(ctx, q.r); ctx.fill(); ctx.restore(); }
  }
  ctx.globalAlpha = 1;
  if (anim && now - anim.t0 >= anim.dur) finishAnim(now);
}
// ---------- mechanic cells (drawn every frame: glass breaks, boxes move) ----------
const PORTAL_COL = ['#8a6cf0', '#22a99a', '#f06a9b'];
// while a slide is still travelling, the glass / box it will hit stay as they were
const shownType = i => { if (anim && !anim.undo && anim.m.cells.length) for (const [j, o] of anim.m.mut) if (j === i) return o; return st.t[i]; };
function drawMechs(now) {
  const c = lay.cell, T = E.T;
  if (boxAnim && now - boxAnim.t0 > 140) boxAnim = null;
  for (let i = 0; i < L.open.length; i++) {
    const t = shownType(i); if (t === T.FLOOR || t === T.WALL) continue;
    if (st.filled[i] && t !== T.BOX) continue; // the body covers walkable mechanics once crossed
    const p = center(i), x = p.x - c / 2, y = p.y - c / 2, d = L.d[i];
    ctx.save();
    if (t === T.GLASS) {
      ctx.fillStyle = 'rgba(160,214,236,.9)'; ctx.strokeStyle = '#6fb3cf'; ctx.lineWidth = c * .05;
      ctx.beginPath(); ctx.roundRect(x + c * .08, y + c * .08, c * .84, c * .84, c * .14); ctx.fill(); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.lineWidth = c * .06; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x + c * .28, y + c * .6); ctx.lineTo(x + c * .6, y + c * .28); ctx.moveTo(x + c * .45, y + c * .72); ctx.lineTo(x + c * .72, y + c * .45); ctx.stroke();
    } else if (t === T.BOX) {
      let bx = p.x, by = p.y;
      if (boxAnim && boxAnim.to === i) { const f = center(boxAnim.from), u = Math.min(1, (now - boxAnim.t0) / 140); bx = f.x + (p.x - f.x) * u; by = f.y + (p.y - f.y) * u; }
      const X = bx - c / 2, Y = by - c / 2;
      ctx.fillStyle = '#b97a43'; ctx.strokeStyle = '#7a4b25'; ctx.lineWidth = c * .06;
      ctx.beginPath(); ctx.roundRect(X + c * .1, Y + c * .1, c * .8, c * .8, c * .1); ctx.fill(); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(X + c * .2, Y + c * .2); ctx.lineTo(X + c * .8, Y + c * .8); ctx.moveTo(X + c * .8, Y + c * .2); ctx.lineTo(X + c * .2, Y + c * .8); ctx.stroke();
    } else if (t === T.ARROW) {
      ctx.translate(p.x, p.y); ctx.rotate([-Math.PI / 2, 0, Math.PI / 2, Math.PI][d]);
      ctx.fillStyle = '#e39a3b'; ctx.beginPath(); ctx.moveTo(c * .3, 0); ctx.lineTo(-c * .16, -c * .26); ctx.lineTo(-c * .05, 0); ctx.lineTo(-c * .16, c * .26); ctx.closePath(); ctx.fill();
    } else if (t === T.TURN) { // a rail from one open side to the other; the closed side is shaded like a wall
      const mid = k => [[p.x, y], [x + c, p.y], [p.x, y + c], [x, p.y]][k];
      const a = mid(d), b = mid([3, 0, 1, 2][d]);
      const K = [a[0] === p.x ? b[0] : a[0], a[1] === p.y ? b[1] : a[1]]; // the cell corner between the open sides
      const A2 = [2 * a[0] - K[0], 2 * a[1] - K[1]], B2 = [2 * b[0] - K[0], 2 * b[1] - K[1]], F = [A2[0] + B2[0] - K[0], A2[1] + B2[1] - K[1]];
      ctx.fillStyle = 'rgba(150,92,52,.32)'; ctx.beginPath(); ctx.moveTo(...a); ctx.quadraticCurveTo(...K, ...b); ctx.lineTo(...B2); ctx.lineTo(...F); ctx.lineTo(...A2); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = '#e39a3b'; ctx.lineWidth = c * .12; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(...a); ctx.quadraticCurveTo(...K, ...b); ctx.stroke();
    } else if (t === T.PIT) {
      ctx.fillStyle = '#5a3a24'; ctx.beginPath(); ctx.ellipse(p.x, p.y, c * .36, c * .3, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#2a1a10'; ctx.beginPath(); ctx.ellipse(p.x, p.y + c * .04, c * .26, c * .2, 0, 0, Math.PI * 2); ctx.fill();
    } else if (t === T.PORTAL) { // a ring open on its face side, coloured by pair
      const col = PORTAL_COL[pairOf(i) % 3];
      const ang = [-Math.PI / 2, 0, Math.PI / 2, Math.PI][d];
      ctx.strokeStyle = col; ctx.lineWidth = c * .12; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.arc(p.x, p.y, c * .3, ang + .7, ang - .7 + Math.PI * 2); ctx.stroke();
      ctx.globalAlpha = .35; ctx.fillStyle = col; ctx.beginPath(); ctx.arc(p.x, p.y, c * .22, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }
}
const pairOf = i => { const k = Object.keys(lv.portals || {}).find(k => { const [x, y] = k.split(',').map(Number); return y * L.W + x === i; }); return k ? lv.portals[k][1] : 0; };
function star(g, r) { g.beginPath(); for (let i = 0; i < 10; i++) { const a = i * Math.PI / 5 - Math.PI / 2, rr = i % 2 ? r * .45 : r; g.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); } g.closePath(); }

// ---------- home scene: the dog solves the 4×4 spiral on a loop ----------
const home = (() => {
  const hc = $('homeCv'), hg = hc.getContext('2d');
  const demo = { grid: ['S...', '....', '....', '....'] };
  let HL, hs, hlay, hboard, hdpr = 1, plan = [], step = 0, t0 = 0, on = false, raf = 0, phase = 'wait', from = null, hfx = D.newFace(), last = 0;
  function resize() {
    const r = hc.getBoundingClientRect(); if (!r.width) return;
    hdpr = Math.min(2.5, devicePixelRatio || 1); hc.width = r.width * hdpr; hc.height = r.height * hdpr;
    HL = E.parse(demo); hlay = R.layout(HL, r.width, r.height, 48); hboard = R.bakeBoard(HL, hlay, hdpr, depth, 0);
  }
  function reset(now = performance.now()) { HL = HL || E.parse(demo); hs = E.newState(HL); plan = E.analyse(demo).solution; step = 0; phase = 'wait'; t0 = now; hfx = D.newFace(); }
  const cen = i => ({ x: hlay.ox + (i % HL.W + .5) * hlay.cell, y: hlay.oy + (((i / HL.W) | 0) + .5) * hlay.cell });
  const dur = () => 180 + hs.moves.at(-1).cells.length * 95;
  function frame(now) {
    raf = 0; if (!on) return;
    if (!hboard) resize(); if (!hboard) { raf = requestAnimationFrame(frame); return; }
    const dt = Math.min(.05, (now - (last || now)) / 1000); last = now;
    let el = now - t0;
    if (phase === 'wait' && el > 620) {
      if (step < plan.length) { from = hs.head; E.apply(HL, hs, plan[step++]); phase = 'move'; t0 = now; }
      else if (el > 2000) { phase = 'rewind'; t0 = now; }
    } else if (phase === 'move' && el >= dur()) { phase = 'wait'; t0 = now; D.trigger(hfx, 'squish', .14); }
    else if (phase === 'rewind' && el >= 1000) reset(now);
    // A transition changes the time origin. Never use the previous phase's elapsed time.
    el = Math.max(0, now - t0);
    hg.setTransform(1, 0, 0, 1, 0, 0); hg.clearRect(0, 0, hc.width, hc.height); hg.drawImage(hboard, 0, 0); hg.setTransform(hdpr, 0, 0, hdpr, 0, 0);
    const pending = phase === 'move' ? new Set(hs.moves.at(-1).cells) : null;
    for (let i = 0; i < HL.open.length; i++) if (HL.open[i] && (phase === 'rewind' || !hs.filled[i] || pending?.has(i))) { const p = cen(i); R.paw(hg, p.x, p.y, hlay.cell * .42, R.PAL.paw); }
    let pts = [cen(HL.start)]; const mv = hs.moves, moving = phase === 'move';
    for (let i = 0; i < mv.length - (moving ? 1 : 0); i++) pts.push(cen(mv[i].cells.at(-1)));
    let dir = [0, 1];
    if (moving) { const a = mv.at(-1), e = cen(a.cells.at(-1)), f = cen(from), u = Math.min(1, el / dur()), k = u * u * (3 - 2 * u); pts.push({ x: f.x + (e.x - f.x) * k, y: f.y + (e.y - f.y) * k }); dir = E.DIRS[a.dir]; }
    else if (mv.length) dir = E.DIRS[mv.at(-1).dir];
    if (phase === 'rewind') { const u = Math.min(1, el / 1000); pts = truncate(pts, polyLen(pts) * (1 - u * u * (3 - 2 * u))); }
    const state = phase === 'rewind' ? 'idle' : E.won(HL, hs) && !moving ? 'happy' : moving ? 'slide' : 'idle';
    D.stepFace(hfx, dt, { state, look: dir });
    const sq = phase === 'wait' && el < 170 && mv.length ? Math.sin(el / 170 * Math.PI) * .5 * (1 - el / 170) : 0;
    D.drawDog(hg, pts, hlay.cell, { fx: hfx, dir, state, squash: sq, stretch: moving ? .07 : 0, t: now / 1000, tailDir: [0, -1], depth });
    raf = requestAnimationFrame(frame);
  }
  return {
    start() { if (on) return; on = true; last = 0; resize(); reset(); raf = requestAnimationFrame(frame); },
    stop() { on = false; if (raf) cancelAnimationFrame(raf); raf = 0; },
    resize() { if (on) resize(); },
    rebake() { hboard = null; },
  };
})();

// ---------- debug / playtest hooks ----------
window.LongDogGame = {
  start, undo, restart, input, state: () => ({ idx, head: st && st.head, count: st && st.count, floor: st && st.need, over, mood, rewinding: !!rewind }),
  solve: () => S && S.hint(st), hint: () => hint && hint.dir, tick: () => draw(performance.now()),
  cellCenter: i => { const r = cv.getBoundingClientRect(), p = center(i); return { x: r.left + p.x, y: r.top + p.y }; }, // page coords, for tap tests
};

Promise.all([D.load(), R.load()]).then(() => { home.rebake(); if (L) resize(); kick(); });
renderMenus();
function fromHash() {
  const n = parseInt(location.hash.slice(1), 10);
  if (n >= 1 && n <= LEVELS.length) { if (!(L && idx === n - 1 && $('game').classList.contains('on'))) start(n - 1); return true; }
  return false;
}
addEventListener('hashchange', fromHash);
if (!fromHash()) show('map');
})();
